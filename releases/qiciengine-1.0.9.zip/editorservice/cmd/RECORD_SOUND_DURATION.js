/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 记录声音时长
 */
M.COMMAND.registerCmd({
    name : 'RECORD_SOUND_DURATION',
    main : function(socket, cookie, args) {
        var sound = args.sound;
        var duration = args.duration;
        var module = G.load('module/SoundDuration.js');
        module.recordSoundDuration(sound, duration);
    }
});
