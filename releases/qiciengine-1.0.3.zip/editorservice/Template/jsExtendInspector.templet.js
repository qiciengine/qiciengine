// extend editor's inspector
G.extend.inspector('qc.demo.__SCRIPT_NAME__', function() {
    // Default drawing
    //this.defaultDraw();

    // Custom drawing
    //var gui = qc.editor.gui; ...
});
