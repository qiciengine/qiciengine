/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 负责记录前端推送的声音 duration 数据，写入到 meta 文件中
 * android 机很容易发生 duration 错误的情况，此时使用 meta 中的时间
 */
var fs = require('fs-extra');
var path = require('path');

var soundDuration = {};
var saveToPath = 'Assets/meta/soundDuration.js';

// 关注切换工程，清空 uuid 记录
G.emitter.on('switchProject', function() {
    // 从配置中获取初始信息
    soundDuration = null;
    try {
        var fileContent = fs.readFileSync(path.join(G.gameRoot, saveToPath));
        var match = fileContent.match(/^soundDurationMap = (.*)/);
        if (match)
            soundDurationMap = JSON.parse(match[1]);
    }
    catch(e) { }

    if (!soundDuration) soundDuration = {};
});

// 关注生成游戏的模板，填入 duration 数据
G.emitter.on('genTemplateContent', function(eventInfo) {
    // 只记录存在的资源，清理下 soundDuration
    var uuid2file = G.gameFiles.uuid2file;
    var urlExists = {};
    var metaChanged = false;

    for (var uuid in uuid2file)
        urlExists[uuid2file[uuid]] = true;

    for (var url in soundDuration) {
        if (urlExists[url])
            continue;

        // 不存在的资源被记录，需要删除
        metaChanged = true;
        delete soundDuration[url];
    }

    if (metaChanged) {
        save();
    }

    var content = eventInfo.content;

    // 判定 soundDuration 数据长度
    if (!Object.keys(soundDuration).length) {
        // 没有任何数据配置
        eventInfo.content = content.replace(/__SOUND_DURATION__/g, '');
    }
    else {
        var publish = eventInfo.publish;

        var dstPath = './' + saveToPath;
        if (!publish) {
            // 增加唯一标记码确保不被缓存
            dstPath = M.USER_SCRIPTS.addJsExtToDenyCache(dstPath, true);
        }

        // 写入数据
        eventInfo.content = content.replace(/__SOUND_DURATION__/g, "'" + dstPath + "',");
    }
});

// 发生数据变更，写入到文件中
var save = function() {
    fs.writeFileSync(path.join(G.gameRoot, saveToPath),
        'soundDurationMap = ' + JSON.stringify(soundDuration, null, 2) + ';\n');
};

// 前端推送过来声音时长数据
module.exports.recordSoundDuration = function(url, duration) {
    if (!duration ||
        typeof duration !== 'number')
        return;

    // 确保所有斜杠的风格统一
    url = M.USER_SCRIPTS.toUnixPath(url);

    if (soundDuration[url] === duration)
        return;

    // 记录并 mark 数据为脏，后续需要写入文件
    soundDuration[url] = duration;
    save();
};
