var __CLASS_NAME__ = defineBehaviour('__PACKAGE_NAME__.__CLASS_NAME__', qc.Behaviour, function() {
        var self = this;

        __FIELDS_DEFAULT__

        self.runInEditor = __RUN_IN_EDITOR__;
    },
    {
        __FIELDS_LIST__
    }
);

__CLASS_NAME__.prototype.awake = function() {

};

__ONENABLE_FUNC__
__ONDISABLE_FUNC__
__ONCLICK_FUNC__
__PREUPDATE_FUNC__
__UPDATE_FUNC__
__POSTUPDATE_FUNC__
