/**
 * @author linyw
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 文本打包规则
 */

M.PACK_RULE.text = {
    type : G.ASSET_TYPE.ASSET_TEXT,
    require : [
        '.txt'
    ],
    serialize : 'JSON'
};