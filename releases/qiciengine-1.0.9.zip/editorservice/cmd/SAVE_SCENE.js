/**
 * @author weism
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 保存场景
 */

M.COMMAND.registerCmd({
    name : 'SAVE_SCENE',
    main : function(socket, cookie, data) {
        var name = data.name;
        var data = data.data;

        var ret = M.SCENE_MANAGER.saveScene(name, data);
        if (ret) {
            // 重新生成游戏启动文件
            G.log.debug('update scene settings.');
            M.PROJECT.genGameHTML();
        }
        return ret;
    }
});
