var __CLASS_NAME__ = __PACKAGE_NAME__.__CLASS_NAME__ = function() {

};
__CLASS_NAME__.prototype = {};
__CLASS_NAME__.prototype.constructor = __CLASS_NAME__;
