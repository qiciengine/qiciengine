/**
 * @author lijh
 * copyright 2015 Qcplay All Rights Reserved.
 */

/**
 * 圆形发射区域
 */
var Circle = qc.ParticleSystem.Zones.Circle = function(radius) {
    qc.ParticleSystem.Zones.Zone.call(this);

    this.geometry = new qc.Circle(0, 0, radius * 2);
};
Circle.prototype = Object.create(qc.ParticleSystem.Zones.Zone.prototype);
Circle.prototype.constructor = Circle;

/**
 * 生成一个随机发射位置
 */
Circle.prototype.getRandom = function() {
    var t = 2 * Math.PI * Math.random();

    this._random.x = this.geometry.x + this.geometry.radius * Math.random() * Math.cos(t);
    this._random.y = this.geometry.y + this.geometry.radius * Math.random() * Math.sin(t);
}

