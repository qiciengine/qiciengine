/**
 * @author wudm
 * copyright 2016 Qcplay All Rights Reserved.
 */

var Body = {};
Body.TYPE = {};
Body.TYPE.STATIC = 0;
Body.TYPE.KINEMATIC = 1;
Body.TYPE.DYNAMIC = 2;

Body.FIXTURE_TYPE = {};
Body.FIXTURE_TYPE.POLYGON = 0;
Body.FIXTURE_TYPE.CIRCLE = 1;
Body.FIXTURE_TYPE.CHAIN = 2;

// Box2d body 脚本扩展显示
G.extend.inspector('qc.Box2D.Body', function() {
    var self = this;
    var target = self.target;
    var gui = qc.editor.gui;

    gui.columnWidths = ['90+0.1', '60+0.3'];

    // 绘制形状
    var typeItems = [ 'Static', 'Dynamic' ];
    gui.line([
        gui.text('Type'),
        typeDownList = gui.dropDownList({ items : typeItems, bind : 'gameObject._body.type' })
    ]);

    var body = target.gameObject._body;
    typeDownList.value = typeItems[body.type === Body.TYPE.DYNAMIC ? 1 : 0];
    typeDownList.syncToGame = function(v) {
        var type = typeItems.indexOf(v) || 0;
        if (type === 1)
            body.type = Body.TYPE.DYNAMIC;
        else
            body.type = Body.TYPE.STATIC;

        self.repaint();
    };
    typeDownList.syncToComp = function(value) {
        this.value = typeItems[body.type === Body.TYPE.DYNAMIC ? 1 : 0];
    };

    // 是否子弹属性
    if (body.type !== Body.TYPE.STATIC) {
        gui.line([
            gui.text('Bullet'),
            gui.checkBox({ bind : 'gameObject._body.bullet' })
        ]);

        // 是否固定 rotation
        gui.line([
            gui.text('fixedRotation'),
            gui.checkBox({ bind : 'gameObject._body.fixedRotation' })
        ]);

        // 设置是否激活中
        gui.line([
            gui.text('awake'),
            gui.checkBox({ bind : 'gameObject._body.isAwake' })
        ]);

        // 重力倍数
        gui.line([
            gui.text('gravityScale'),
            gui.numberInput({ bind : 'gameObject._body.gravityScale' })
        ]);

        // 当前线速度
        gui.columnWidths = ['70+0.1', 20, '30+0.1', 20, '30+0.1'];
        qc.editor.InspectorUtil.drawPoint(target, 'linearVelocity', 'gameObject._body.linearVelocity');

        // 线性阻尼
        gui.columnWidths = ['90+0.1', '60+0.3'];
        gui.line([
            gui.text('linearDamping'),
            gui.numberInput({ bind : 'gameObject._body.linearDamping' })
        ]);

        // 角速度
        gui.line([
            gui.text('angularVelocity'),
            gui.numberInput({ bind : 'gameObject._body.angularVelocity' })
        ]);

        // 线性阻尼
        gui.line([
            gui.text('angularDamping'),
            gui.numberInput({ bind : 'gameObject._body.angularDamping' })
        ]);
    }

    // Fixture 设置
    gui.columnWidths = [self.indent, '60+0.1', '60+0.3' ];
    var title = gui.titleLine('Fixture');
    var fixtureTypeItems = [ 'Polygon', 'Circle' ];
    var fixtureTypeDownList;

    var bindFixture = function(key) {
        return 'gameObject._body.fixture[0].' + key;
    };
    title.add(gui.line([
        gui.empty(),
        gui.text('Type'),
        fixtureTypeDownList = gui.dropDownList({ items : fixtureTypeItems, bind : bindFixture('type') })
    ]));
    var fixture = target.gameObject._body.fixture[0];
    fixtureTypeDownList.value = fixtureTypeItems[fixture.type === Body.FIXTURE_TYPE.CIRCLE ? 1 : 0];
    fixtureTypeDownList.syncToGame = function(v) {
        var type = fixtureTypeItems.indexOf(v) || 0;
        if (type === 1)
            fixture.type = Body.FIXTURE_TYPE.CIRCLE;
        else
            fixture.type = Body.FIXTURE_TYPE.POLYGON;
    };
    fixtureTypeDownList.syncToComp = function(value) {
        this.value = fixtureTypeItems[fixture.type === Body.FIXTURE_TYPE.CIRCLE ? 1 : 0];
    };

    // 密度
    if (body.type !== Body.TYPE.STATIC) {
        title.add(gui.line([
            gui.empty(),
            gui.text('density'),
            gui.numberInput({ bind : bindFixture('density') })
        ]));
    }

    // 摩擦力
    title.add(gui.line([
        gui.empty(),
        gui.text('friction'),
        gui.numberInput({ bind : bindFixture('friction') })
    ]));

    // 恢复属性
    title.add(gui.line([
        gui.empty(),
        gui.text('restitution'),
        gui.numberInput({ bind : bindFixture('restitution') })
    ]));

    // 是否是传感器
    title.add(gui.line([
        gui.empty(),
        gui.text('Is Sensor'),
        gui.checkBox({ bind : bindFixture('sensor') })
    ]));
});
