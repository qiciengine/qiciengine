/**
 * 用户自定义脚本.
 */
(function(window, Object, undefined) {

{{body}}

}).call(this, this, Object);
