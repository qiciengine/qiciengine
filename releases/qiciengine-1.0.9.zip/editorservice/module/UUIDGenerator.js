/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 资源 uuid 管理，尽可能复用之前使用过的 uuid
 */
var fs = require('fs-extra');
var path = require('path');

var uuidRecord = {};
var saveToPath = 'ProjectSetting/uuidHistory.setting';

// 关注切换工程，清空 uuid 记录
G.emitter.on('switchProject', function() {
    // 从配置中获取初始信息
    try {
        uuidRecord = fs.readJsonSync(path.join(G.gameRoot, saveToPath), { throws : false });
    }
    catch(e) {}
    if (!uuidRecord) uuidRecord = {};
});

// 关注 url map 被保存
G.emitter.on('saveUrlMap', function(urlMap) {
    var changed = false;

    for (var uuid in urlMap) {
        var url = urlMap[uuid];

        if (uuidRecord[url] === uuid)
            // 已经有这份记录了
            continue;

        // 记录下来，并且标记有变动
        changed = true;
        uuidRecord[url] = uuid;
    }

    if (!changed) return;

    // 发生变动，则写入文件中
    G.load('filesystem/FsExpand').writeJsonSync(path.join(G.gameRoot, saveToPath), uuidRecord);
});

// 申请新的 uuid
G.resUUID = function(url) {
    url = M.util.toUnixPath(path.relative(G.gameRoot, url));
    return uuidRecord[url] || G.uuid();
};
